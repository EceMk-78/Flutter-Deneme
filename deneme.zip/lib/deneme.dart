import 'package:flutter/material.dart';

class Deneme extends StatefulWidget {
  const Deneme({Key? key}) : super(key: key);

  @override
  State<Deneme> createState() => _DenemeState();
}

class _DenemeState extends State<Deneme> {
  String veri = "Değişkenden Gelen Veri";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Başka Sayfadan Veri Geliyor",
            style: TextStyle(
              color: Colors.white,
            )),
        backgroundColor: Color(0xff644bf2),
      ),
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: Color(0xff1b969a),
        unselectedItemColor: Colors.grey,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Ana Sayfa"),
          BottomNavigationBarItem(
              icon: Icon(
                Icons.search,
              ),
              label: "Arama"),
          BottomNavigationBarItem(icon: Icon(Icons.add), label: "Ekle"),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              child: Text("Menü", style: Theme.of(context).textTheme.headline2),
              decoration: BoxDecoration(
                color: Color(0xbd8b5dd4),
              ),
            ),
            ListTile(
              title: Text("Ayarlar"),
              leading: Icon(Icons.settings),
            ),
            ListTile(
              title: Text("Siparişlerim"),
              leading: Icon(Icons.shopping_bag),
            ),
            ListTile(
              title: Text("Çıkış"),
              leading: Icon(Icons.exit_to_app),
            ),
          ],
        ),
      ),
      body: Center(
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            Text(
              veri,
              style: TextStyle(
                fontSize: 24,
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  veri = "Değişken Güncellendi";
                });
              },
              child: Text("Güncelle"),
            ),
          ],
        ),
      ),
    );
  }
}
